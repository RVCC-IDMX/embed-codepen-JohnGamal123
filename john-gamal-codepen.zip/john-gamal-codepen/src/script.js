function changeHeader() {
  document.body.style.color = "magenta";
  change.onclick - changeHeader();
}
